function doGet(e) {
  var page = e.parameter.page || 'landing page';
  return HtmlService.createHtmlOutputFromFile(page);
}
